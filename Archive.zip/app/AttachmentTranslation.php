<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AttachmentTranslation extends Model
{
	public $timestamps = false;
}
