<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProjectTypeTranslation extends Model
{
	public $timestamps = false;
}
