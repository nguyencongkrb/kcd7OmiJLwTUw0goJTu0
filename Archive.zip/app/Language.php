<?php

namespace App;

class Language extends BaseModel
{
	public $timestamps = false;
}
