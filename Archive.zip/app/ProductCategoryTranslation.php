<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductCategoryTranslation extends Model
{
	public $timestamps = false;
}
