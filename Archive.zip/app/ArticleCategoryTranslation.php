<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ArticleCategoryTranslation extends Model
{
	public $timestamps = false;
}
