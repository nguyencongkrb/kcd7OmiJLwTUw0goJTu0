<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProjectCategoryTranslation extends Model
{
	public $timestamps = false;
}
